import React from 'react';
import { useSelectorCart } from '../hooks/useSelector';
// components
import ItemCart from '../components/Cart/ItemCart';
import ShippingAddress from '../components/Cart/ShippingAddress';

const Cart = () => {
  const { totalPrice, cart } = useSelectorCart();
  React.useEffect(() => window.scrollTo({ top: 0 }), []);
  return (
    <>
      <h1 className="page-title">Cart</h1>
      {(cart.length === 0 && <p className="empty">Cart is empty</p>) || (
        <div className="container">
          <div className="shopping-cart-box">
            {cart.map((item, indx) => (
              <ItemCart key={indx} item={item} />
            ))}
          </div>
          <div className="delivery-information">
            <div className="order-summary">
              <h2>Order summary</h2>
              <div className="order-summary-container">
                <p className="order-summary-container__title">Subtotal</p>
                <p className="order-summary-container__price">
                  {totalPrice > 500 || totalPrice === 0 ? totalPrice : totalPrice - 10}$
                </p>
              </div>
              <div className="order-summary-container">
                <p className="order-summary-container__title">Shipping</p>
                <p className="order-summary-container__price">
                  {totalPrice > 500 || totalPrice === 0 ? '0$' : '10$'}
                </p>
              </div>
              <div className="order-summary-container">
                <p className="orderSummary_container__title">Total price</p>
                <p className="orderSummary_container__price totalPrice">{totalPrice}$</p>
              </div>
              <ShippingAddress cart={cart} totalPrice={totalPrice} />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Cart;
