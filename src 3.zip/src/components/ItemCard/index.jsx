import React from 'react';
import { Link } from 'react-router-dom';

const ItemCard = (item) => {
  return (
    <>
      <div className="item">
        <img className="item_IMG" src={item.picture[0]} alt="" />
        <div className="item_overlay">
          <Link to={`/${item.gender}/${item.id}`} className="custom-link" state={item}>
            <p className="showMore">Show more</p>
          </Link>
        </div>
        <div className="item_characterisation flex-column">
          <div className="item_title">{<h1>{`${item.brand} ${item.model}`}</h1>}</div>
          <div className="item_price">
            {item.oldPrice > 0 ? <p className="oldPrice">{`${item.oldPrice}$`}</p> : ''}
            <p>{item.price}$</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default ItemCard;
