import React from 'react';

const HeaderSpecialOffer = () => {
  return <p className="headerSpecialOffer">Free shipping on orders of $500 </p>;
};
export default HeaderSpecialOffer;
