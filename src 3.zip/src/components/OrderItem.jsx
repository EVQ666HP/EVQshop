import React from 'react';

const OrderItem = ({ item }) => {
  const dateParts = item.date.split(' ');
  const date = `${dateParts[1]} ${dateParts[2]} ${dateParts[3]} ${dateParts[4]}`;
  const orderBox = [...new Array(4)].map((_, index) => {
    return item.items[index];
  });
  return (
    <div className="orderBox">
      <div className="orderBox_column flex-column">
        <div className="orderBox_row">
          {orderBox.slice(0, 2).map((e) => {
            return (
              <img
                className={e ? 'orderBox_img' : 'orderBox_img emptyBox'}
                src={e !== undefined ? e.picture : 'https://imgur.com/rrWKR0f.png'}
                alt=""
              />
            );
          })}
        </div>

        <div className="orderBox_row">
          {orderBox.slice(2, 4).map((e) => {
            return (
              <img
                className={e ? 'orderBox_img' : 'orderBox_img emptyBox'}
                src={e !== undefined ? e.picture : 'https://imgur.com/rrWKR0f.png'}
                alt=""
              />
            );
          })}
        </div>
      </div>
      <div className="orderBox_Info">
        <div className="orderBox_date">
          Date: <span>{date}</span>
        </div>
        <div className="orderBox_price">
          Price: <span>{item.price}$</span>
        </div>
      </div>
    </div>
  );
};

export default OrderItem;
