import React from 'react';
import { Link } from 'react-router-dom';
const Banner = () => {
  return (
    <div className="banner">
      <div className="banner_left">
        <p className="banner_left__p">New collection</p>
        <img
          className="banner_left__img"
          src="https://tres-bien.com/media/wysiwyg/blog/2302/2023-02-15_nike_stussy.jpg"
          alt=""
        />
        <div className="banner_left__overlay">
          <Link to="New-collection" className="custom-link">
            <div className="showMore">Show more</div>
          </Link>
        </div>
      </div>

      <div className="banner_right flex-column ">
        <div className="banner_top flex-column ">
          <h1>REAL DESIGNS BY REAL ARTISTS FOR REAL PEOPLE</h1>
          <img className="borderText" src="https://i.imgur.com/M325DAQ.png" alt="erorr" />
          <p>
            We're cgallenging conventional retail, putting an end to dead stock, unconventional
            waste and more funtastic
          </p>
        </div>
        <div className="banner_bottom">
          <div className="banner_bottom__left">
            <p className="banner_bottom__leftP">Final sale</p>
            <img
              className="banner_bottom__leftIMG"
              src="https://tres-bien.com/media/wysiwyg/start/2308/s_230811_prada.jpg"
              alt=""
            />
            <div className="banner_bottom__overlay">
              <Link to="Final-sale" className="custom-link">
                <div className="showMore">Show more</div>
              </Link>
            </div>
          </div>
          <div className="banner_bottom__right">
            <p className=" banner_bottom__rightP">NIKE AIR</p>
            <img
              className="banner_bottom__rightIMG"
              src="https://tres-bien.com/media/catalog/product/cache/92c32ae85341dabe805aa810fb1f52cd/f/o/footwear_230810_026.jpg"
              alt=""
            />
            <div className="banner_bottom__overlayR">
              <div className="showMore">Show more</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
